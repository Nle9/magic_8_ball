import 'package:flutter/material.dart';
import 'dart:math';
void main() => runApp(
      MaterialApp(
        home: BallPage(),
      ),
    );

class BallPage extends StatelessWidget {
  @override
Widget build(BuildContext context) {
  return MaterialApp(
   title: 'Ask me anything',
    home: Scaffold(
      backgroundColor: Colors.blue,
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        title: Text('Ask me anything'),
      ),
      body: Ball(),
    )
  );
  }
}
class Ball extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _BallState();
  }

}

class _BallState extends State<Ball> {
  var ballNumber = 1;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
      children: <Widget> [
      Expanded(
        child: FlatButton(
          onPressed:(){
            print('I got clicked');
    setState(() {
              ballNumber = Random().nextInt(4) + 1;
            });
          },
          child: Image.asset('images/ball$ballNumber.png'),
        ),
      ),
        Expanded(
          child: FlatButton(
            onPressed: () { setState(() {
              ballNumber = 1;
            });
            },
            child: Text('Reset'),
          ),
        ),
    ],
    ),
    );
  }
}
